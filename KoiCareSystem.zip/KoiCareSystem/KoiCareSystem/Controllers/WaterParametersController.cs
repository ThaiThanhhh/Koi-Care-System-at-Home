﻿using Microsoft.AspNetCore.Mvc;
using KoiCareSystem.Models;
using System.Collections.Generic;
using System.Linq;

namespace KoiCareSystem.Controllers
{
    public class WaterParametersController : Controller
    {
        // Danh sách thông số nước lưu trữ tạm thời (có thể thay bằng cơ sở dữ liệu thật)
        private static List<WaterParameter> waterParametersList = new List<WaterParameter>();

        // GET: WaterParameters/Index
        public IActionResult Index()
        {
            return View(waterParametersList);
        }

        // GET: WaterParameters/Create
        public IActionResult Create()
        {
            return View();
        }

        // POST: WaterParameters/Create
        [HttpPost]
        public IActionResult Create(WaterParameter waterParameter)
        {
            waterParameter.Id = waterParametersList.Count > 0 ? waterParametersList.Max(wp => wp.Id) + 1 : 1;
            waterParameter.Timestamp = DateTime.Now;
            waterParametersList.Add(waterParameter);
            return RedirectToAction("Index");
        }

        // GET: WaterParameters/Edit/{id}
        public IActionResult Edit(int id)
        {
            var waterParameter = waterParametersList.FirstOrDefault(wp => wp.Id == id);
            if (waterParameter == null)
                return NotFound();

            return View(waterParameter);
        }

        // POST: WaterParameters/Edit/{id}
        [HttpPost]
        public IActionResult Edit(WaterParameter updatedWaterParameter)
        {
            var waterParameter = waterParametersList.FirstOrDefault(wp => wp.Id == updatedWaterParameter.Id);
            if (waterParameter == null)
                return NotFound();

            waterParameter.Temperature = updatedWaterParameter.Temperature;
            waterParameter.Salt = updatedWaterParameter.Salt;
            waterParameter.PH = updatedWaterParameter.PH;
            waterParameter.Oxygen = updatedWaterParameter.Oxygen;
            waterParameter.Nitrite = updatedWaterParameter.Nitrite;
            waterParameter.Nitrate = updatedWaterParameter.Nitrate;
            waterParameter.Phosphate = updatedWaterParameter.Phosphate;
            waterParameter.Timestamp = DateTime.Now;

            return RedirectToAction("Index");
        }

        // GET: WaterParameters/Delete/{id}
        public IActionResult Delete(int id)
        {
            var waterParameter = waterParametersList.FirstOrDefault(wp => wp.Id == id);
            if (waterParameter == null)
                return NotFound();

            return View(waterParameter);
        }

        // POST: WaterParameters/Delete/{id}
        [HttpPost, ActionName("Delete")]
        public IActionResult DeleteConfirmed(int id)
        {
            var waterParameter = waterParametersList.FirstOrDefault(wp => wp.Id == id);
            if (waterParameter != null)
            {
                waterParametersList.Remove(waterParameter);
            }
            return RedirectToAction("Index");
        }
    }
}
