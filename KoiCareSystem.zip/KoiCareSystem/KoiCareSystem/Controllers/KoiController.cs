﻿using Microsoft.AspNetCore.Mvc;
using KoiCareSystem.Models;
using System.Collections.Generic;
using System.Linq;

public class KoiController : Controller
{
    // Danh sách cá Koi lưu trữ tạm thời (có thể thay bằng cơ sở dữ liệu)
    private static List<Koi> koiList = new List<Koi>();

    public IActionResult Index()
    {
        // Hiển thị danh sách cá Koi
        return View(koiList);
    }

    public IActionResult Create()
    {
        // Hiển thị form thêm mới cá Koi
        return View();
    }

    [HttpPost]
    public IActionResult Create(Koi koi)
    {
        // Thêm cá Koi vào danh sách
        koi.Id = koiList.Count > 0 ? koiList.Max(k => k.Id) + 1 : 1;
        koiList.Add(koi);
        return RedirectToAction("Index");
    }

    public IActionResult Edit(int id)
    {
        // Tìm cá Koi cần sửa dựa trên ID
        var koi = koiList.FirstOrDefault(k => k.Id == id);
        if (koi == null) return NotFound();
        return View(koi);
    }

    [HttpPost]
    public IActionResult Edit(Koi updatedKoi)
    {
        // Cập nhật thông tin cá Koi
        var koi = koiList.FirstOrDefault(k => k.Id == updatedKoi.Id);
        if (koi == null) return NotFound();

        koi.Name = updatedKoi.Name;
        koi.Age = updatedKoi.Age;
        koi.Length = updatedKoi.Length;
        koi.Weight = updatedKoi.Weight;
        koi.Breed = updatedKoi.Breed;
        koi.Gender = updatedKoi.Gender;
        koi.Origin = updatedKoi.Origin;

        return RedirectToAction("Index");
    }

    public IActionResult Delete(int id)
    {
        // Tìm cá Koi cần xóa dựa trên ID
        var koi = koiList.FirstOrDefault(k => k.Id == id);
        if (koi == null) return NotFound();
        return View(koi);
    }

    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        // Xóa cá Koi khỏi danh sách
        var koi = koiList.FirstOrDefault(k => k.Id == id);
        if (koi != null)
        {
            koiList.Remove(koi);
        }
        return RedirectToAction("Index");
    }
}
