﻿using Microsoft.AspNetCore.Mvc;
using KoiCareSystem.Models;
using System.Collections.Generic;
using System.Linq;

public class AquariumController : Controller
{
    // Danh sách bể cá lưu trữ tạm thời (có thể thay bằng cơ sở dữ liệu)
    private static List<Aquarium> aquariumList = new List<Aquarium>();

    public IActionResult Index()
    {
        // Hiển thị danh sách bể cá
        return View(aquariumList);
    }

    public IActionResult Create()
    {
        // Hiển thị form thêm mới bể cá
        return View();
    }

    [HttpPost]
    public IActionResult Create(Aquarium aquarium)
    {
        // Thêm bể cá vào danh sách
        aquarium.Id = aquariumList.Count > 0 ? aquariumList.Max(a => a.Id) + 1 : 1;
        aquariumList.Add(aquarium);
        return RedirectToAction("Index");
    }

    public IActionResult Edit(int id)
    {
        // Tìm bể cá cần sửa dựa trên ID
        var aquarium = aquariumList.FirstOrDefault(a => a.Id == id);
        if (aquarium == null) return NotFound();
        return View(aquarium);
    }

    [HttpPost]
    public IActionResult Edit(Aquarium updatedAquarium)
    {
        // Cập nhật thông tin bể cá
        var aquarium = aquariumList.FirstOrDefault(a => a.Id == updatedAquarium.Id);
        if (aquarium == null) return NotFound();

        aquarium.Name = updatedAquarium.Name;
        aquarium.Depth = updatedAquarium.Depth;
        aquarium.Volume = updatedAquarium.Volume;
        aquarium.DrainsCount = updatedAquarium.DrainsCount;
        aquarium.PumpCapacity = updatedAquarium.PumpCapacity;
        aquarium.ImageUrl = updatedAquarium.ImageUrl;

        return RedirectToAction("Index");
    }

    public IActionResult Delete(int id)
    {
        // Tìm bể cá cần xóa dựa trên ID
        var aquarium = aquariumList.FirstOrDefault(a => a.Id == id);
        if (aquarium == null) return NotFound();
        return View(aquarium);
    }

    [HttpPost, ActionName("Delete")]
    public IActionResult DeleteConfirmed(int id)
    {
        // Xóa bể cá khỏi danh sách
        var aquarium = aquariumList.FirstOrDefault(a => a.Id == id);
        if (aquarium != null)
        {
            aquariumList.Remove(aquarium);
        }
        return RedirectToAction("Index");
    }
}
