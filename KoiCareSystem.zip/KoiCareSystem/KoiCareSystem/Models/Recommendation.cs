﻿namespace KoiCareSystem.Models
{
    public class Recommendation
    {
    }
}
