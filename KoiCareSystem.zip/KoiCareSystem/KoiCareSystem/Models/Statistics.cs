﻿namespace KoiCareSystem.Models
{
    public class Statistics
    {
    }
}
