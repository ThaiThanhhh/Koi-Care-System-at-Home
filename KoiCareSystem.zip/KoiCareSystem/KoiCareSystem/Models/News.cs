﻿namespace KoiCareSystem.Models
{
    public class News
    {
    }
}
